/**
 * ui.js — CertiChain v4
 * - Nav pill indicator animation
 * - Mobile menu toggle
 * - Workflow interactive carousel
 */

// ════════════════════════════════════════════
//  NAV PILL INDICATOR
// ════════════════════════════════════════════
function updateNavIndicator(activeItem) {
  const indicator = document.getElementById('navIndicator');
  const pill = activeItem?.closest('.nav-pill');
  if (!indicator || !activeItem || !pill) return;
  const pr = pill.getBoundingClientRect();
  const ir = activeItem.getBoundingClientRect();
  indicator.style.left  = (ir.left - pr.left) + 'px';
  indicator.style.width = ir.width + 'px';
}

window.addEventListener('resize', () => {
  const a = document.querySelector('.nav-pill-item.active');
  if (a) updateNavIndicator(a);
});

// ════════════════════════════════════════════
//  MOBILE MENU
// ════════════════════════════════════════════
function toggleMobileMenu() {
  const menu   = document.getElementById('mobileMenu');
  const toggle = document.getElementById('menuToggle');
  if (!menu || !toggle) return;
  const open = menu.classList.toggle('open');
  toggle.classList.toggle('open', open);
}

document.addEventListener('click', e => {
  const menu   = document.getElementById('mobileMenu');
  const toggle = document.getElementById('menuToggle');
  if (menu?.classList.contains('open')
    && !menu.contains(e.target)
    && !toggle?.contains(e.target)) {
    menu.classList.remove('open');
    toggle?.classList.remove('open');
  }
});

// ════════════════════════════════════════════
//  WORKFLOW CAROUSEL
// ════════════════════════════════════════════
let wfCurrentStep = 0;
let wfAutoTimer   = null;
const WF_TOTAL       = 4;
const WF_AUTO_MS     = 5000;
const WF_PROGRESS_MS = 4800;

function goToStep(index, dir) {
  const slides = document.querySelectorAll('.wf-slide');
  const items  = document.querySelectorAll('.wf-step-item');
  const dots   = document.querySelectorAll('.wf-dot');
  if (!slides.length) return;

  // Clamp
  if (index < 0) index = WF_TOTAL - 1;
  if (index >= WF_TOTAL) index = 0;
  if (index === wfCurrentStep) return;

  const goRight = dir ? dir === 'next' : index > wfCurrentStep;

  // Exit current
  const cur = slides[wfCurrentStep];
  cur.classList.remove('active');
  cur.classList.add(goRight ? 'exit-left' : 'exit-right');
  setTimeout(() => cur.classList.remove('exit-left', 'exit-right'), 500);

  // Enter new
  const nxt = slides[index];
  nxt.style.transition = 'none';
  nxt.style.transform  = goRight ? 'translateX(60px) scale(0.96)' : 'translateX(-60px) scale(0.96)';
  nxt.style.opacity    = '0';

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      nxt.style.transition = '';
      nxt.style.transform  = '';
      nxt.style.opacity    = '';
      nxt.classList.add('active');
    });
  });

  // Update UI elements
  items.forEach((el, i) => el.classList.toggle('active', i === index));
  dots.forEach((el, i)  => el.classList.toggle('active', i === index));

  // Reset bars
  document.querySelectorAll('.wf-step-bar').forEach(bar => {
    bar.style.transition = 'none';
    bar.style.width = '0%';
  });

  // Animate active bar
  const activeBar = items[index]?.querySelector('.wf-step-bar');
  if (activeBar) {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      activeBar.style.transition = `width ${WF_PROGRESS_MS}ms linear`;
      activeBar.style.width = '100%';
    }));
  }

  wfCurrentStep = index;
  resetAutoPlay();
}

function nextStep() { goToStep(wfCurrentStep + 1, 'next'); }
function prevStep() { goToStep(wfCurrentStep - 1, 'prev'); }

function resetAutoPlay() {
  clearInterval(wfAutoTimer);
  wfAutoTimer = setInterval(nextStep, WF_AUTO_MS);
}

function initWorkflow() {
  const section = document.getElementById('workflowSec');
  if (!section) return;

  // Reset to step 0
  wfCurrentStep = 0;
  document.querySelectorAll('.wf-slide').forEach((s, i) => s.classList.toggle('active', i === 0));
  document.querySelectorAll('.wf-step-item').forEach((s, i) => s.classList.toggle('active', i === 0));
  document.querySelectorAll('.wf-dot').forEach((d, i) => d.classList.toggle('active', i === 0));

  // Progress bar step 0
  const firstBar = section.querySelector('.wf-step-item.active .wf-step-bar');
  if (firstBar) {
    firstBar.style.transition = 'none';
    firstBar.style.width = '0%';
    requestAnimationFrame(() => requestAnimationFrame(() => {
      firstBar.style.transition = `width ${WF_PROGRESS_MS}ms linear`;
      firstBar.style.width = '100%';
    }));
  }

  // Pause on hover
  section.addEventListener('mouseenter', () => clearInterval(wfAutoTimer), { once: false });
  section.addEventListener('mouseleave', resetAutoPlay, { once: false });

  // Touch / swipe
  let tx = 0, ty = 0;
  const track = document.getElementById('wfTrack');
  if (track) {
    track.addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
    track.addEventListener('touchend', e => {
      const dx = e.changedTouches[0].clientX - tx;
      const dy = e.changedTouches[0].clientY - ty;
      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
        dx < 0 ? nextStep() : prevStep();
      }
    }, { passive: true });
  }

  // Keyboard
  document.onkeydown = e => {
    const r = section.getBoundingClientRect();
    if (r.top < window.innerHeight && r.bottom > 0) {
      if (e.key === 'ArrowRight') nextStep();
      if (e.key === 'ArrowLeft')  prevStep();
    }
  };

  resetAutoPlay();
}

// Start workflow on first load
document.addEventListener('DOMContentLoaded', () => setTimeout(initWorkflow, 400));
