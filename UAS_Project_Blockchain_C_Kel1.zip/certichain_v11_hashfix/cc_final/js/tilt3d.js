/**
 * tilt3d.js — CertiChain v4
 * WOW-level 3D Tilt Effect
 * Fitur:
 *  - Gyroscopic rotateX/Y mengikuti kursor presisi tinggi
 *  - Holographic conic-gradient rainbow shimmer
 *  - Spotlight glare yang bergerak
 *  - Depth layers translateZ (icon > title > desc)
 *  - Floating particle burst saat hover masuk
 *  - Bottom glow shadow berwarna per card
 *  - Spring physics pada return animation
 */

// ── Config ──
const TILT = {
  maxDeg    : 18,       // sudut maks (makin besar makin dramatis)
  scale     : 1.055,    // zoom saat hover
  resetMs   : 500,      // ms animasi balik
  spring    : 'cubic-bezier(0.23,1,0.32,1)',
  particles : 12,       // jumlah partikel per burst
  particleMs: 900,      // durasi hidup partikel
};

/**
 * Inisialisasi semua .feat-card
 * Dipanggil ulang setiap kali halaman home di-render
 */
function init3DTilt() {
  document.querySelectorAll('.feat-card').forEach(card => {
    // Hindari double-init
    if (card._tiltInited) return;
    card._tiltInited = true;

    // ── mouseenter: aktifkan state ──
    card.addEventListener('mouseenter', e => {
      card.classList.add('tilting');
      // Instant transition (override CSS .55s return)
      card.style.transition = 'transform 0.08s ease, box-shadow 0.08s ease';
      burstParticles(card);
    });

    // ── mousemove: hitung & terapkan transform ──
    card.addEventListener('mousemove', e => {
      const r    = card.getBoundingClientRect();
      const relX = (e.clientX - r.left) / r.width  - 0.5;  // -0.5 ~ +0.5
      const relY = (e.clientY - r.top)  / r.height - 0.5;

      const rotY =  relX * TILT.maxDeg;
      const rotX = -relY * TILT.maxDeg;

      // Terapkan via CSS vars (wrapper perspective menghandle depth)
      card.style.setProperty('--rot-x', `${rotX}deg`);
      card.style.setProperty('--rot-y', `${rotY}deg`);
      card.style.setProperty('--scale', TILT.scale);
      card.style.transform = `rotateX(${rotX}deg) rotateY(${rotY}deg) scale3d(${TILT.scale},${TILT.scale},${TILT.scale})`;

      // Update shimmer & spotlight position (persen)
      const px = ((e.clientX - r.left) / r.width  * 100).toFixed(1);
      const py = ((e.clientY - r.top)  / r.height * 100).toFixed(1);
      card.style.setProperty('--mx', `${px}%`);
      card.style.setProperty('--my', `${py}%`);

      // Update shine layer
      const shine = card.querySelector('.feat-shine');
      if (shine) {
        shine.style.background = `radial-gradient(
          circle 180px at ${px}% ${py}%,
          rgba(255,255,255,0.30) 0%,
          rgba(255,255,255,0.08) 45%,
          transparent 70%
        )`;
      }
    });

    // ── mouseleave: spring return ──
    card.addEventListener('mouseleave', () => {
      card.classList.remove('tilting');
      card.style.transition = `transform ${TILT.resetMs}ms ${TILT.spring}, box-shadow ${TILT.resetMs}ms ${TILT.spring}`;
      card.style.transform  = 'rotateX(0deg) rotateY(0deg) scale3d(1,1,1)';
      card.style.setProperty('--rot-x', '0deg');
      card.style.setProperty('--rot-y', '0deg');
      card.style.setProperty('--scale', '1');
      card.style.setProperty('--mx', '50%');
      card.style.setProperty('--my', '50%');

      // Reset shine
      const shine = card.querySelector('.feat-shine');
      if (shine) shine.style.background = '';
    });
  });
}

/**
 * Particle burst — titik-titik kecil meledak keluar saat mouseenter
 * @param {HTMLElement} card
 */
function burstParticles(card) {
  // Ambil warna dari data-color di .feat-particles
  const pEl   = card.querySelector('.feat-particles');
  const color = pEl?.dataset.color || '#F6851B';

  const rect = card.getBoundingClientRect();
  // Spawn dari tengah atas card (area ikon)
  const originX = rect.width / 2;
  const originY = rect.height * 0.3;

  for (let i = 0; i < TILT.particles; i++) {
    const dot = document.createElement('div');
    dot.style.cssText = `
      position: absolute;
      width: ${3 + Math.random() * 4}px;
      height: ${3 + Math.random() * 4}px;
      border-radius: 50%;
      background: ${color};
      left: ${originX}px;
      top:  ${originY}px;
      pointer-events: none;
      z-index: 10;
      opacity: 0.85;
      transform: translate(-50%, -50%);
    `;

    if (pEl) {
      pEl.appendChild(dot);

      // Animasi
      const angle    = (Math.PI * 2 / TILT.particles) * i + (Math.random() - 0.5) * 0.8;
      const distance = 30 + Math.random() * 50;
      const dx       = Math.cos(angle) * distance;
      const dy       = Math.sin(angle) * distance;
      const duration = TILT.particleMs * (0.6 + Math.random() * 0.5);

      dot.animate([
        { transform: `translate(-50%, -50%) translate(0px, 0px)`, opacity: 0.85 },
        { transform: `translate(-50%, -50%) translate(${dx}px, ${dy}px)`, opacity: 0 }
      ], {
        duration,
        easing: 'cubic-bezier(0,0.9,0.57,1)',
        fill: 'forwards'
      }).onfinish = () => dot.remove();
    }
  }
}
