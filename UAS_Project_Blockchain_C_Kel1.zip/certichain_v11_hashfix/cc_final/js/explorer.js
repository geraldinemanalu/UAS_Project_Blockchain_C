/**
 * explorer.js — CertiChain v4
 */

async function explorerSearch() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask!','error'); return; }
  const id = document.getElementById('explorerSearchId')?.value;
  if (!id||id<1) { showAlert('Masukkan ID yang valid!','error'); return; }
  const el = document.getElementById('explorerResult');
  try {
    showTxProgress(true,'Mencari...');
    const [cId,name,course,date,isValid] = await contract.getCertificate(Number(id));
    el.innerHTML = buildExpCard(cId,name,course,date,isValid,true);
    el.classList.remove('hidden');
  } catch(_) {
    el.innerHTML=`<div style="padding:14px;background:var(--red-bg);border:1px solid var(--red-bd);border-radius:var(--r);color:var(--red-d);font-size:.87rem;">✕ ID tidak ditemukan.</div>`;
    el.classList.remove('hidden');
  } finally { showTxProgress(false); }
}

async function explorerLoadAll() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask!','error'); return; }
  const listEl = document.getElementById('explorerList');
  try {
    showTxProgress(true,'Mengambil dari blockchain...');
    const total = Number(await contract.certificateCount());
    if (total===0) { listEl.innerHTML=`<div class="exp-empty"><span class="exp-empty-icon">⊙</span><p>Belum ada sertifikat.</p></div>`; return; }
    showTxProgress(true,`Memuat ${total} sertifikat...`);
    const certs = await Promise.all(Array.from({length:total},(_,i)=>contract.getCertificate(i+1)));
    listEl.innerHTML = certs.map(c=>buildExpCard(c[0],c[1],c[2],c[3],c[4],false)).join('');
    showAlert(`${total} sertifikat dimuat!`,'success');
  } catch(err) { showAlert('Gagal memuat.','error'); }
  finally { showTxProgress(false); }
}

function buildExpCard(certId,name,course,date,isValid,hl) {
  const cls=isValid?'valid':'revoked', lbl=isValid?'AKTIF':'DICABUT', dt=formatDateShort(date);
  const base=`<div class="exp-cert-top"><span class="exp-cert-id">ID #${certId}</span><span class="exp-cert-status ${cls}">${lbl}</span></div>
    <div class="exp-cert-name">${name}</div><div class="exp-cert-course">${course}</div>
    <div class="exp-cert-foot"><span class="exp-cert-date">${dt}</span></div>`;
  return hl
    ? `<div style="background:var(--bg2);border:1.5px solid var(--orange-bd);border-radius:var(--r-lg);padding:20px;box-shadow:var(--shadow);">${base}</div>`
    : `<div class="exp-cert-card">${base}</div>`;
}
