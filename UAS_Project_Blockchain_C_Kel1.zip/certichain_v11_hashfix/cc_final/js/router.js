/**
 * router.js — CertiChain v4
 * SPA Navigation — controls page visibility
 */

const PAGES = ['home','app','explorer','about'];

function navigateTo(name) {
  if (!PAGES.includes(name)) name = 'home';

  // Update nav pill active state
  document.querySelectorAll('.nav-pill-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === name);
  });
  document.querySelectorAll('.mobile-nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.page === name);
  });

  // Show/hide pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const pg = document.getElementById(`page-${name}`);
  if (pg) pg.classList.add('active');

  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Update nav pill indicator
  setTimeout(() => {
    const active = document.querySelector('.nav-pill-item.active');
    if (active) updateNavIndicator(active);
  }, 50);

  // Per-page hooks
  if (name === 'home') {
    if (typeof init3DTilt === 'function') init3DTilt();
    if (typeof initWorkflow === 'function') setTimeout(initWorkflow, 200);
    if (typeof loadStats === 'function') loadStats();
  } else {
    // Stop workflow autoplay when leaving home
    if (typeof wfAutoTimer !== 'undefined') clearInterval(wfAutoTimer);
  }
  if (name === 'explorer' && typeof loadStats === 'function') loadStats();
}

// Header scroll effect
window.addEventListener('scroll', () => {
  const h = document.getElementById('header');
  if (!h) return;
  const y = window.scrollY;
  h.classList.toggle('at-top', y < 20);
  h.classList.toggle('scrolled', y > 60);
}, { passive: true });

// Init on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  // Auto reconnect wallet
  if (window.ethereum) {
    window.ethereum.request({ method: 'eth_accounts' })
      .then(accs => { if (accs.length > 0 && typeof connectWallet === 'function') connectWallet(); })
      .catch(() => {});
  }
  // Load home page
  navigateTo('home');
  // Set initial header state
  const h = document.getElementById('header');
  if (h) h.classList.add('at-top');
});
