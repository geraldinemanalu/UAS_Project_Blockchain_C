/**
 * blockchain.js — CertiChain
 * MetaMask connect + semua fungsi smart contract
 */

const CONTRACT_ADDRESS = "0x3A47f2eAD6228bEd643bF669060E9a73A8369B43";

// ABI contract BARU (dengan fungsi hash)
const CONTRACT_ABI = [
  "function owner() view returns (address)",
  "function certificateCount() view returns (uint256)",
  "function authorizedIssuers(address) view returns (bool)",
  "function createCertificate(string _recipientName, string _courseName) returns (uint256)",
  "function getCertificate(uint256 _id) view returns (uint256 id, string recipientName, string courseName, uint256 issueDate, bool isValid, address issuedBy, bytes32 certHash)",
  "function getCertificateByHash(bytes32 _certHash) view returns (uint256 id, string recipientName, string courseName, uint256 issueDate, bool isValid, address issuedBy, bytes32 certHash)",
  "function verifyCertificate(uint256 _id) view returns (bool isAuthentic, string message)",
  "function verifyCertificateByHash(bytes32 _certHash) view returns (bool isAuthentic, string message)",
  "function revokeCertificate(uint256 _id)",
  "function revokeCertificateByHash(bytes32 _certHash)",
  "event CertificateCreated(uint256 indexed id, string recipientName, string courseName, address issuedBy, bytes32 certHash)",
  "event CertificateRevoked(uint256 indexed id, address revokedBy)"
];

// ABI contract LAMA (fallback)
const CONTRACT_ABI_LEGACY = [
  "function owner() view returns (address)",
  "function certificateCount() view returns (uint256)",
  "function authorizedIssuers(address) view returns (bool)",
  "function createCertificate(string _recipientName, string _courseName) returns (uint256)",
  "function getCertificate(uint256 _id) view returns (uint256 id, string recipientName, string courseName, uint256 issueDate, bool isValid, address issuedBy)",
  "function verifyCertificate(uint256 _id) view returns (bool isAuthentic, string message)",
  "function revokeCertificate(uint256 _id)",
  "event CertificateCreated(uint256 indexed id, string recipientName, string courseName, address issuedBy)",
  "event CertificateRevoked(uint256 indexed id, address revokedBy)"
];

let provider    = null;
let signer      = null;
let contract    = null;
let userAddress = null;
let isNewContract = false;

// ════════════════════════════════════════════
//  CONSTANTS
// ════════════════════════════════════════════
const ZERO_HASH = '0x' + '0'.repeat(64);

// ════════════════════════════════════════════
//  UTILITIES
// ════════════════════════════════════════════
function showAlert(msg, type = 'info') {
  const b = document.getElementById('alertBanner');
  if (!b) return;
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  const iconEl = document.getElementById('alertIcon');
  const msgEl  = document.getElementById('alertMsg');
  if (iconEl) iconEl.textContent = icons[type] || 'ℹ';
  if (msgEl)  msgEl.textContent  = msg;
  b.className = `alert-banner alert-${type}`;
  b.classList.remove('hidden');
  clearTimeout(b._t);
  b._t = setTimeout(closeAlert, 5500);
}
function closeAlert() {
  document.getElementById('alertBanner')?.classList.add('hidden');
}

function showTxProgress(show, msg = 'Menunggu konfirmasi...') {
  const txMsg = document.getElementById('txMsg');
  const txPrg = document.getElementById('txProgress');
  if (txMsg) txMsg.textContent = msg;
  if (txPrg) txPrg.classList.toggle('hidden', !show);
}

function formatDate(ts) {
  return new Date(Number(ts) * 1000).toLocaleDateString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}
function formatDateShort(ts) {
  return new Date(Number(ts) * 1000).toLocaleDateString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}
function shortAddr(a) {
  return (!a || a.length < 10) ? a : `${a.slice(0, 6)}...${a.slice(-4)}`;
}
function shortHash(h) {
  return (!h || h.length < 10) ? h : `${h.slice(0, 10)}...${h.slice(-6)}`;
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text)
    .then(() => showAlert('Hash berhasil disalin ke clipboard!', 'success'))
    .catch(() => {
      try {
        const el = document.createElement('textarea');
        el.value = text;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
        showAlert('Hash berhasil disalin!', 'success');
      } catch(_) { showAlert('Gagal menyalin.', 'error'); }
    });
}

// ════════════════════════════════════════════
//  INPUT VALIDATION
//  HANYA terima: angka murni (ID) ATAU 0x + tepat 64 hex (hash)
//  Apapun selain itu = invalid
// ════════════════════════════════════════════
function isHashInput(val) {
  return typeof val === 'string' && /^0x[0-9a-fA-F]{64}$/.test(val.trim());
}
function isIdInput(val) {
  return typeof val === 'string' && /^\d+$/.test(val.trim()) && parseInt(val.trim()) >= 1;
}
function validateInput(val) {
  val = (val || '').trim();
  if (!val) return { valid: false, error: 'Input tidak boleh kosong.' };
  if (isIdInput(val)) return { valid: true, type: 'id', value: parseInt(val) };
  if (isHashInput(val)) return { valid: true, type: 'hash', value: val };
  // Input tidak valid: bukan angka murni dan bukan 0x+64hex
  return {
    valid: false,
    error: 'Input tidak valid. Masukkan nomor ID (contoh: 3) atau hash lengkap (0x diikuti 64 karakter hex).'
  };
}

// ════════════════════════════════════════════
//  HASH GENERATION
//  Menggunakan Web Crypto API (SHA-256 native browser)
//  Input yang PASTI UNIK per sertifikat:
//    - txHash: hash transaksi blockchain (100% unik global)
//    - blockNumber: nomor blok
//    - certId: nomor sertifikat
//    - timestamp: nanosecond via performance.now()
//    - random: 16 byte random entropy
//  Sehingga bahkan 2 sertifikat dengan nama & kursus SAMA
//  di blok yang SAMA pun akan punya hash berbeda.
// ════════════════════════════════════════════
async function generateUniqueHash(certId, name, course, txHash, blockNumber, issuer) {
  const idPart    = String(certId   ?? '');
  const txPart    = String(txHash   ?? '');
  const blkPart   = String(blockNumber ?? '');
  const tsPart    = String(performance.now()); // nanosecond precision
  const rndBytes  = crypto.getRandomValues(new Uint8Array(16));
  const rndHex    = Array.from(rndBytes).map(b => b.toString(16).padStart(2,'0')).join('');

  const rawStr = [
    'certichain-v10',
    idPart, name, course, issuer, txPart, blkPart, tsPart, rndHex
  ].join('|');

  const encoded = new TextEncoder().encode(rawStr);
  const hashBuf = await crypto.subtle.digest('SHA-256', encoded);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return '0x' + hashArr.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Hash deterministik untuk "Lihat Sertifikat" (sertifikat lama yang sudah ada)
// Deterministik = sertifikat yang sama selalu punya hash display yang sama
async function generateDeterministicHash(certId, name, course, issuer, issueDate) {
  const rawStr = [
    'certichain-lookup-v10',
    String(certId), name, course, issuer, String(issueDate)
  ].join('|');
  const encoded = new TextEncoder().encode(rawStr);
  const hashBuf = await crypto.subtle.digest('SHA-256', encoded);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return '0x' + hashArr.map(b => b.toString(16).padStart(2, '0')).join('');
}

// ════════════════════════════════════════════
//  CONTRACT VERSION DETECTION
// ════════════════════════════════════════════
async function detectContractVersion() {
  try {
    await contract.getCertificateByHash(ZERO_HASH);
    isNewContract = true;
  } catch(err) {
    if (err?.reason || err?.message?.includes('tidak ditemukan') || err?.message?.includes('execution reverted')) {
      isNewContract = true;
    } else {
      isNewContract = false;
    }
  }
}

// ════════════════════════════════════════════
//  HASH SCAN FALLBACK (contract lama)
// ════════════════════════════════════════════
async function findIdByHashScan(targetHash) {
  const total = Number(await contract.certificateCount());
  if (total === 0) return null;
  showTxProgress(true, `Mencari hash di ${total} sertifikat...`);
  const norm = targetHash.toLowerCase();
  for (let i = 1; i <= total; i++) {
    try {
      const d = await contract.getCertificate(i);
      const h = d[6];
      if (h && h !== ZERO_HASH && h.toLowerCase() === norm) return i;
    } catch(_) {}
  }
  return null;
}

// ════════════════════════════════════════════
//  RESOLVE CERTIFICATE (by ID or hash)
// ════════════════════════════════════════════
async function resolveCertificate(rawVal) {
  rawVal = rawVal.trim();

  if (isIdInput(rawVal)) {
    const id = parseInt(rawVal);
    const d  = await contract.getCertificate(id);
    const onChainHash = (d[6] && d[6] !== ZERO_HASH) ? d[6] : null;
    return {
      id: d[0], recipientName: d[1], courseName: d[2],
      issueDate: d[3], isValid: d[4], issuedBy: d[5],
      certHash: onChainHash
    };
  }

  if (isHashInput(rawVal)) {
    if (isNewContract) {
      try {
        const d = await contract.getCertificateByHash(rawVal);
        const onChainHash = (d[6] && d[6] !== ZERO_HASH) ? d[6] : rawVal;
        return {
          id: d[0], recipientName: d[1], courseName: d[2],
          issueDate: d[3], isValid: d[4], issuedBy: d[5],
          certHash: onChainHash
        };
      } catch(_) {
        throw new Error('Hash sertifikat tidak ditemukan di blockchain.');
      }
    } else {
      const foundId = await findIdByHashScan(rawVal);
      if (!foundId) throw new Error('Hash sertifikat tidak ditemukan.');
      const d = await contract.getCertificate(foundId);
      return {
        id: d[0], recipientName: d[1], courseName: d[2],
        issueDate: d[3], isValid: d[4], issuedBy: d[5],
        certHash: rawVal
      };
    }
  }

  throw new Error('Input tidak valid. Masukkan ID angka atau hash (0x + 64 karakter).');
}

// ════════════════════════════════════════════
//  RESOLVE VERIFY
// ════════════════════════════════════════════
async function resolveVerify(rawVal) {
  rawVal = rawVal.trim();

  if (isIdInput(rawVal)) {
    const id = parseInt(rawVal);
    const [ok, msg] = await contract.verifyCertificate(id);
    return { ok, msg };
  }

  if (isHashInput(rawVal)) {
    if (isNewContract) {
      try {
        const [ok, msg] = await contract.verifyCertificateByHash(rawVal);
        return { ok, msg };
      } catch(_) {
        return { ok: false, msg: 'TIDAK VALID: Hash sertifikat tidak ditemukan.' };
      }
    } else {
      const foundId = await findIdByHashScan(rawVal);
      if (!foundId) return { ok: false, msg: 'TIDAK VALID: Hash sertifikat tidak ditemukan.' };
      const [ok, msg] = await contract.verifyCertificate(foundId);
      return { ok, msg };
    }
  }

  throw new Error('Input tidak valid.');
}

// ════════════════════════════════════════════
//  RESOLVE REVOKE
// ════════════════════════════════════════════
async function resolveRevoke(rawVal) {
  rawVal = rawVal.trim();

  if (isIdInput(rawVal)) {
    const id = parseInt(rawVal);
    const tx = await contract.revokeCertificate(id);
    const receipt = await tx.wait(1);
    return { label: `#${id}`, receipt };
  }

  if (isHashInput(rawVal)) {
    if (isNewContract) {
      try {
        const tx = await contract.revokeCertificateByHash(rawVal);
        const receipt = await tx.wait(1);
        return { label: `Hash ${shortHash(rawVal)}`, receipt };
      } catch(err) {
        if (err.code === 4001) throw err;
        throw new Error(err.reason || 'Hash tidak ditemukan atau tidak berwenang.');
      }
    } else {
      showTxProgress(true, 'Mencari hash...');
      const foundId = await findIdByHashScan(rawVal);
      if (!foundId) throw new Error('Hash sertifikat tidak ditemukan.');
      const tx = await contract.revokeCertificate(foundId);
      const receipt = await tx.wait(1);
      return { label: `Hash ${shortHash(rawVal)} (ID #${foundId})`, receipt };
    }
  }

  throw new Error('Input tidak valid.');
}

// ════════════════════════════════════════════
//  CONNECT WALLET
// ════════════════════════════════════════════
async function connectWallet() {
  if (typeof ethers === 'undefined') {
    showAlert('Library blockchain belum siap. Tunggu sebentar lalu coba lagi.', 'error');
    return;
  }
  if (!window.ethereum) {
    showAlert('MetaMask tidak terdeteksi! Install dulu.', 'error');
    return;
  }
  try {
    showAlert('Membuka MetaMask...', 'info');
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    provider    = new ethers.BrowserProvider(window.ethereum);
    signer      = await provider.getSigner();
    userAddress = await signer.getAddress();
    const net   = await provider.getNetwork();

    if (net.chainId !== 11155111n) {
      showAlert('Ganti jaringan ke Sepolia Testnet di MetaMask!', 'error');
      signer = null; return;
    }

    contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
    document.getElementById('connectBtn')?.classList.add('hidden');
    document.getElementById('walletInfo')?.classList.remove('hidden');
    document.getElementById('networkBadge')?.classList.remove('hidden');
    const waEl = document.getElementById('walletAddress');
    if (waEl) waEl.textContent = shortAddr(userAddress);

    showAlert(`Wallet terhubung: ${shortAddr(userAddress)}`, 'success');
    await detectContractVersion();
    await loadStats();

    window.ethereum.on('accountsChanged', accs => {
      if (!accs.length) { signer = contract = userAddress = null; resetWalletUI(); }
      else window.location.reload();
    });
    window.ethereum.on('chainChanged', () => window.location.reload());
  } catch(err) {
    if (err.code === 4001) showAlert('Koneksi ditolak di MetaMask.', 'error');
    else showAlert('Gagal terhubung: ' + (err.message || ''), 'error');
  }
}

function resetWalletUI() {
  document.getElementById('connectBtn')?.classList.remove('hidden');
  document.getElementById('walletInfo')?.classList.add('hidden');
  document.getElementById('networkBadge')?.classList.add('hidden');
}

async function loadStats() {
  if (!contract) return;
  try {
    const [count, owner] = await Promise.all([
      contract.certificateCount(),
      contract.owner()
    ]);
    document.querySelectorAll('.stat-total').forEach(el => el.textContent = count.toString());
    document.querySelectorAll('.stat-owner').forEach(el => el.textContent = shortAddr(owner));
  } catch(e) { console.warn(e); }
}

// ════════════════════════════════════════════
//  CREATE CERTIFICATE
// ════════════════════════════════════════════
async function createCertificate() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error'); return; }
  const name   = document.getElementById('recipientName')?.value.trim();
  const course = document.getElementById('courseName')?.value.trim();
  if (!name)   { showAlert('Nama peserta tidak boleh kosong!', 'error'); return; }
  if (!course) { showAlert('Nama kursus tidak boleh kosong!', 'error'); return; }

  const btn = document.getElementById('createBtn');
  const res = document.getElementById('createResult');

  try {
    if (btn) btn.disabled = true;
    showTxProgress(true, 'Mengirim ke MetaMask...');
    const tx = await contract.createCertificate(name, course);
    showTxProgress(true, 'Menunggu konfirmasi blockchain...');
    const receipt = await tx.wait(1);

    // ── Ambil ID dan on-chain hash dari event log ──
    let newId    = null;
    let certHash = null;

    try {
      const iface = new ethers.Interface(CONTRACT_ABI);
      for (const log of receipt.logs) {
        try {
          const p = iface.parseLog(log);
          if (p?.name === 'CertificateCreated') {
            newId = p.args.id;
            const raw = p.args.certHash;
            if (raw && raw !== ZERO_HASH) certHash = raw;
            break;
          }
        } catch(_) {}
      }
    } catch(_) {}

    // Fallback: ambil ID dari certificateCount
    if (newId === null) {
      try { newId = await contract.certificateCount(); } catch(_) {}
    }

    // ── Ambil data dari chain ──
    let certData = null;
    if (newId !== null) {
      try {
        const d = await contract.getCertificate(Number(newId));
        const onChainHash = (d[6] && d[6] !== ZERO_HASH) ? d[6] : null;
        certData = {
          id: d[0], recipientName: d[1], courseName: d[2],
          issueDate: d[3], isValid: d[4], issuedBy: d[5],
          certHash: onChainHash
        };
        if (!certHash && certData.certHash) certHash = certData.certHash;
      } catch(_) {}
    }

    // ── Generate hash UNIK off-chain jika contract lama (tidak ada on-chain hash) ──
    // Pakai txHash + blockNumber + random entropy → 100% unik, tidak pernah nabrak
    if (!certHash) {
      certHash = await generateUniqueHash(
        newId,
        name,
        course,
        receipt.hash || receipt.transactionHash || '',
        receipt.blockNumber,
        userAddress
      );
    }

    // ── Tampilkan result box ──
    const hashInfo = certHash
      ? `<br/>🔑 <span style="font-size:.82rem">Hash:</span> <span class="mono-small" title="${certHash}">${shortHash(certHash)}</span> <button class="copy-hash-btn" onclick="copyToClipboard('${certHash}')">Salin Hash</button>`
      : '';

    if (res) {
      res.innerHTML = `✓ Sertifikat #${newId ?? '?'} berhasil diterbitkan!<br/>Block: ${receipt.blockNumber} · Tx: ${shortAddr(receipt.hash)}${hashInfo}`;
      res.className = 'res-box success';
      res.classList.remove('hidden');
    }
    showAlert(`Sertifikat #${newId ?? '?'} berhasil diterbitkan!`, 'success');

    // ── Tampilkan modal dengan data lengkap dan hash unik ──
    if (newId !== null) {
      try {
        await showCertificateModal({
          id           : certData?.id           ?? newId,
          recipientName: certData?.recipientName ?? name,
          courseName   : certData?.courseName    ?? course,
          issueDate    : certData?.issueDate     ?? BigInt(Math.floor(Date.now() / 1000)),
          isValid      : certData?.isValid       ?? true,
          issuedBy     : certData?.issuedBy      ?? userAddress,
          certHash     : certHash   // ← sudah pasti unik dan tidak zero
        });
      } catch(err) {
        console.error('Gagal menampilkan modal:', err);
      }
    }

    // ── Clear form ──
    const nameInput   = document.getElementById('recipientName');
    const courseInput = document.getElementById('courseName');
    if (nameInput)   nameInput.value   = '';
    if (courseInput) courseInput.value = '';

    await loadStats();

  } catch(err) {
    let msg = 'Transaksi gagal.';
    if (err.code === 4001)                          msg = 'Dibatalkan pengguna.';
    else if (err.message?.includes('insufficient')) msg = 'ETH tidak cukup untuk gas!';
    else if (err.reason)                            msg = err.reason;
    if (res) { res.textContent = '✕ ' + msg; res.className = 'res-box error'; res.classList.remove('hidden'); }
    showAlert(msg, 'error');
  } finally {
    if (btn) btn.disabled = false;
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  GET CERTIFICATE
// ════════════════════════════════════════════
async function getCertificate() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error'); return; }

  const inputEl = document.getElementById('getCertId');
  const rawVal  = inputEl?.value?.trim() || '';

  // Validasi input ketat
  const validation = validateInput(rawVal);
  if (!validation.valid) {
    showAlert(validation.error, 'error');
    return;
  }

  try {
    showTxProgress(true, 'Mengambil data dari blockchain...');
    const cert = await resolveCertificate(rawVal);

    document.getElementById('cardId').textContent     = '#' + cert.id.toString();
    document.getElementById('cardName').textContent   = cert.recipientName;
    document.getElementById('cardCourse').textContent = cert.courseName;
    document.getElementById('cardDate').textContent   = formatDate(cert.issueDate);
    document.getElementById('cardIssuer').textContent = cert.issuedBy;

    // ── Hash: on-chain → deterministik off-chain ──
    const hashEl    = document.getElementById('cardHash');
    const hashRowEl = document.getElementById('cardHashRow');

    let displayHash = cert.certHash || null;

    if (!displayHash) {
      // Generate deterministik: sertifikat yang sama → hash display yang sama
      displayHash = await generateDeterministicHash(
        cert.id, cert.recipientName, cert.courseName,
        cert.issuedBy, cert.issueDate
      );
    }

    if (displayHash && hashEl) {
      hashEl.textContent = displayHash;
      hashEl.title       = displayHash;
      hashRowEl?.classList.remove('hidden');
    } else {
      hashRowEl?.classList.add('hidden');
    }

    const badge = document.getElementById('certStatusBadge');
    if (badge) {
      badge.textContent = cert.isValid ? '● AKTIF' : '✕ DICABUT';
      badge.className   = `ic-status ${cert.isValid ? 'valid' : 'revoked'}`;
    }
    document.getElementById('certCard')?.classList.remove('hidden');

    // ── Clear input setelah berhasil ──
    if (inputEl) inputEl.value = '';

    showAlert('Data sertifikat berhasil dimuat!', 'success');

  } catch(err) {
    document.getElementById('certCard')?.classList.add('hidden');
    showAlert('✕ ' + (err.reason || err.message || 'ID/Hash tidak ditemukan.'), 'error');
  } finally {
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  VERIFY CERTIFICATE
// ════════════════════════════════════════════
async function verifyCertificate() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error'); return; }

  const inputEl = document.getElementById('verifyCertId');
  const rawVal  = inputEl?.value?.trim() || '';

  const validation = validateInput(rawVal);
  if (!validation.valid) {
    showAlert(validation.error, 'error');
    return;
  }

  try {
    showTxProgress(true, 'Memverifikasi sertifikat...');
    const { ok, msg } = await resolveVerify(rawVal);

    const label = validation.type === 'hash'
      ? `Hash ${shortHash(rawVal)}`
      : `Sertifikat #${rawVal}`;

    const iconEl   = document.getElementById('verifyIcon');
    const msgEl    = document.getElementById('verifyMsg');
    const statusEl = document.getElementById('verifyStatus');
    const box      = document.getElementById('verifyResult');

    if (iconEl)   iconEl.textContent   = ok ? '✓' : '✕';
    if (msgEl)    msgEl.textContent    = msg;
    if (statusEl) statusEl.textContent = ok ? `${label} valid dan aktif` : `${label} tidak valid`;
    if (box) {
      box.className = `verify-display ${ok ? 'valid' : 'invalid'}`;
      box.classList.remove('hidden');
    }

    // ── Clear input setelah verifikasi ──
    if (inputEl) inputEl.value = '';

    showAlert(ok ? `${label} VALID ✓` : `${label} tidak valid`, ok ? 'success' : 'error');

  } catch(err) {
    const box = document.getElementById('verifyResult');
    const iconEl   = document.getElementById('verifyIcon');
    const msgEl    = document.getElementById('verifyMsg');
    const statusEl = document.getElementById('verifyStatus');
    if (iconEl)   iconEl.textContent   = '?';
    if (msgEl)    msgEl.textContent    = err.message || 'Gagal memverifikasi.';
    if (statusEl) statusEl.textContent = 'ID/Hash tidak ditemukan.';
    if (box) { box.className = 'verify-display invalid'; box.classList.remove('hidden'); }
    showAlert('✕ ' + (err.message || 'Gagal memverifikasi.'), 'error');
  } finally {
    showTxProgress(false);
  }
}

// ════════════════════════════════════════════
//  REVOKE CERTIFICATE
// ════════════════════════════════════════════
async function revokeCertificate() {
  if (!contract) { showAlert('Hubungkan wallet MetaMask terlebih dahulu!', 'error'); return; }

  const inputEl = document.getElementById('revokeCertId');
  const rawVal  = inputEl?.value?.trim() || '';

  const validation = validateInput(rawVal);
  if (!validation.valid) {
    showAlert(validation.error, 'error');
    return;
  }

  const labelPreview = validation.type === 'hash'
    ? `hash ${shortHash(rawVal)}`
    : `#${rawVal}`;

  if (!window.confirm(`⚠️ Yakin mencabut sertifikat ${labelPreview}?\n\nTindakan ini PERMANEN dan tidak bisa dibatalkan.`)) return;

  const btn = document.getElementById('revokeBtn');
  const res = document.getElementById('revokeResult');

  try {
    if (btn) btn.disabled = true;
    showTxProgress(true, 'Mengirim transaksi pencabutan...');
    const { label, receipt } = await resolveRevoke(rawVal);

    if (res) {
      res.innerHTML = `✓ Sertifikat ${label} berhasil dicabut!<br/>Block: ${receipt.blockNumber}`;
      res.className = 'res-box success';
      res.classList.remove('hidden');
    }
    // ── Clear input setelah berhasil ──
    if (inputEl) inputEl.value = '';
    showAlert(`Sertifikat ${label} berhasil dicabut.`, 'success');

  } catch(err) {
    let msg = 'Gagal mencabut.';
    if (err.code === 4001) msg = 'Dibatalkan pengguna.';
    else if (err.reason)   msg = err.reason;
    else if (err.message)  msg = err.message;
    if (res) { res.textContent = '✕ ' + msg; res.className = 'res-box error'; res.classList.remove('hidden'); }
    showAlert(msg, 'error');
  } finally {
    if (btn) btn.disabled = false;
    showTxProgress(false);
  }
}

// NOTE: Fungsi switchTab() TIDAK didefinisikan di sini.
// Setiap halaman (index.html dan user.html) mendefinisikan
// switchTab() miliknya sendiri secara inline untuk menghindari
// konflik nama fungsi global.
