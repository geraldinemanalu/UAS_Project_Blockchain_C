/**
 * auth.js — CertiChain
 * Sistem autentikasi terpusat (localStorage-based, demo)
 * Dipakai oleh: login.html, register.html, index.html, user.html
 */

const AUTH_KEY      = 'cc_accounts';   // daftar akun tersimpan
const SESSION_KEY   = 'cc_session';    // sesi aktif
const REMEMBER_KEY  = 'cc_remember';  // remember-me

/* ── Akun bawaan (seed) ──────────────────────────── */
const DEFAULT_ACCOUNTS = [
  {
    id       : 'usr_admin_001',
    name     : 'Administrator',
    email    : 'admin@certichain.id',
    password : 'Admin@123',
    role     : 'admin',
    avatar   : '🛡️',
    createdAt: '2024-01-01T00:00:00Z'
  },
  {
    id       : 'usr_user_001',
    name     : 'Budi Santoso',
    email    : 'user@certichain.id',
    password : 'User@123',
    role     : 'user',
    avatar   : '👤',
    createdAt: '2024-01-01T00:00:00Z'
  }
];

/* ── Helpers penyimpanan ─────────────────────────── */
function getAccounts() {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveAccounts(accounts) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(accounts));
}

function initAccounts() {
  // Jika belum ada data, isi dengan akun bawaan
  if (!getAccounts()) saveAccounts(DEFAULT_ACCOUNTS);
}

/* ── Session ─────────────────────────────────────── */
function getSession() {
  try {
    // Cek sessionStorage dulu, lalu localStorage (remember-me)
    const s = sessionStorage.getItem(SESSION_KEY) || localStorage.getItem(REMEMBER_KEY);
    return s ? JSON.parse(s) : null;
  } catch { return null; }
}

function saveSession(user, remember = false) {
  const sess = {
    id   : user.id,
    name : user.name,
    email: user.email,
    role : user.role,
    avatar: user.avatar,
    loginAt: new Date().toISOString()
  };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(sess));
  if (remember) localStorage.setItem(REMEMBER_KEY, JSON.stringify(sess));
}

function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(REMEMBER_KEY);
}

/* ── Auth actions ────────────────────────────────── */

/**
 * Login — cocokkan email + password + role
 * Returns: { ok, user, error }
 */
function authLogin(email, password, role) {
  initAccounts();
  const accounts = getAccounts();
  const user = accounts.find(
    a => a.email.toLowerCase() === email.toLowerCase()
      && a.password === password
      && a.role === role
  );
  if (!user) {
    // Berikan pesan spesifik
    const byEmail = accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
    if (!byEmail)      return { ok: false, error: 'Email tidak terdaftar.' };
    if (byEmail.role !== role) return { ok: false, error: `Akun ini bukan ${role === 'admin' ? 'Admin' : 'Pengguna'}.` };
    return { ok: false, error: 'Password salah.' };
  }
  return { ok: true, user };
}

/**
 * Register — daftarkan akun baru
 * Returns: { ok, user, error }
 */
function authRegister(name, email, password, role) {
  initAccounts();
  const accounts = getAccounts();

  // Validasi
  if (!name.trim())            return { ok: false, error: 'Nama tidak boleh kosong.' };
  if (!email.includes('@'))    return { ok: false, error: 'Format email tidak valid.' };
  if (password.length < 6)    return { ok: false, error: 'Password minimal 6 karakter.' };
  if (accounts.find(a => a.email.toLowerCase() === email.toLowerCase()))
    return { ok: false, error: 'Email sudah terdaftar.' };

  const newUser = {
    id       : 'usr_' + Date.now(),
    name     : name.trim(),
    email    : email.toLowerCase().trim(),
    password : password,
    role     : role,
    avatar   : role === 'admin' ? '🛡️' : '👤',
    createdAt: new Date().toISOString()
  };
  accounts.push(newUser);
  saveAccounts(accounts);
  return { ok: true, user: newUser };
}

/**
 * Guard: pastikan sudah login, redirect jika belum
 * @param {string|null} requiredRole  'admin' | 'user' | null (siapapun)
 * @param {string} redirectTo         halaman tujuan jika tidak login
 */
function authGuard(requiredRole = null, redirectTo = 'login.html') {
  initAccounts();
  const sess = getSession();
  if (!sess) {
    window.location.replace(redirectTo);
    return null;
  }
  if (requiredRole && sess.role !== requiredRole) {
    // Login tapi role salah → arahkan ke dashboard yang sesuai
    window.location.replace(sess.role === 'admin' ? 'index.html' : 'user.html');
    return null;
  }
  return sess;
}

/**
 * Redirect jika sudah login (untuk login/register page)
 */
function authRedirectIfLoggedIn() {
  initAccounts();
  const sess = getSession();
  if (sess) {
    window.location.replace(sess.role === 'admin' ? 'index.html' : 'user.html');
  }
}

/**
 * Logout
 */
function authLogout() {
  clearSession();
  window.location.replace('login.html');
}
