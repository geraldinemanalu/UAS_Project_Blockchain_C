/**
 * certificate.js — CertiChain v4
 * Modal sertifikat formal + download PNG + konfeti
 */

// ── Muat html2canvas dengan fallback multi-CDN (jika satu CDN diblokir) ──
function loadHtml2CanvasWithFallback() {
  const SOURCES = [
    'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js',
    'https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js'
  ];
  let i = 0;
  return new Promise((resolve, reject) => {
    function tryNext() {
      if (i >= SOURCES.length) { reject(new Error('Semua sumber CDN html2canvas gagal dimuat.')); return; }
      const s = document.createElement('script');
      s.src = SOURCES[i];
      s.onload = () => { if (window.html2canvas) resolve(); else { i++; tryNext(); } };
      s.onerror = () => { i++; tryNext(); };
      document.head.appendChild(s);
    }
    tryNext();
  });
}

async function showCertificateModal(cert) {
  document.getElementById('certModalName').textContent   = cert.recipientName;
  document.getElementById('certModalCourse').textContent = cert.courseName;
  document.getElementById('certModalId').textContent     = '#' + cert.id.toString();
  document.getElementById('certModalDate').textContent   = formatDate(cert.issueDate);
  document.getElementById('certModalIssuer').textContent = cert.issuedBy;

  const hashEl    = document.getElementById('certModalHash');
  const hashRowEl = document.getElementById('certModalHashRow');
  const ZERO_HASH = '0x' + '0'.repeat(64);

  // Hash sudah di-resolve dan dijamin unik oleh blockchain.js sebelum memanggil fungsi ini.
  // Fungsi ini hanya perlu menampilkannya — tidak perlu generate ulang.
  let finalHash = (cert.certHash && cert.certHash !== ZERO_HASH && cert.certHash !== '0x')
    ? cert.certHash
    : null;

  // Safety fallback: jika entah bagaimana hash masih kosong, generate deterministik
  if (!finalHash) {
    try {
      const rawStr  = `certichain-modal|${cert.id}|${cert.recipientName}|${cert.courseName}|${cert.issuedBy}|${cert.issueDate}`;
      const encoded = new TextEncoder().encode(rawStr);
      const hashBuf = await crypto.subtle.digest('SHA-256', encoded);
      const hashArr = Array.from(new Uint8Array(hashBuf));
      finalHash     = '0x' + hashArr.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch(_) {}
  }

  if (hashEl && finalHash) {
    hashEl.textContent = shortHash(finalHash);
    hashEl.title       = finalHash;
    hashEl.setAttribute('data-full', finalHash);
    if (hashRowEl) hashRowEl.classList.remove('hidden');
  } else {
    if (hashRowEl) hashRowEl.classList.add('hidden');
  }

  document.getElementById('certModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  triggerConfetti();
}

function closeCertModal() {
  document.getElementById('certModal').classList.add('hidden');
  document.body.style.overflow = '';
}

// Klik di luar modal → tutup
document.addEventListener('click', e => {
  const overlay = document.getElementById('certModal');
  if (e.target === overlay) closeCertModal();
});
document.addEventListener('keydown', e => { if (e.key==='Escape') closeCertModal(); });

// ── Download PNG ──
async function downloadCertificate() {
  const certEl = document.getElementById('certificateDocument');
  if (!certEl) return;
  const btn = document.querySelector('.cert-dl-btn');
  const orig = btn.innerHTML;
  btn.innerHTML = '⏳ Memproses...'; btn.disabled = true;
  try {
    if (!window.html2canvas) {
      await loadHtml2CanvasWithFallback();
    }
    const canvas = await window.html2canvas(certEl, {
      scale: 3, useCORS: true, backgroundColor: '#FFFEF7', logging: false
    });
    const a = document.createElement('a');
    a.download = `CertiChain_${document.getElementById('certModalName').textContent.replace(/\s+/g,'_')}_${document.getElementById('certModalId').textContent}.png`;
    a.href = canvas.toDataURL('image/png');
    a.click();
    showAlert('Sertifikat berhasil diunduh!', 'success');
  } catch(err) {
    console.error(err);
    showAlert('Gagal unduh. Coba screenshot manual.', 'error');
  } finally { btn.innerHTML = orig; btn.disabled = false; }
}

// ── Konfeti ──
function triggerConfetti() {
  const canvas = document.createElement('canvas');
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
  canvas.style.cssText = 'position:fixed;inset:0;z-index:800;pointer-events:none;';
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const COLORS = ['#F6851B','#DAA520','#1DAB87','#037DD6','#FFD700','#FF6B6B','#4ECDC4'];
  const W = canvas.width, H = canvas.height;
  const pieces = Array.from({length:90},()=>({
    x: Math.random()*W, y: -20-Math.random()*120,
    w: 6+Math.random()*10, h: 4+Math.random()*6,
    color: COLORS[Math.floor(Math.random()*COLORS.length)],
    speed: 2+Math.random()*4, angle: Math.random()*Math.PI*2,
    spin: (Math.random()-.5)*.2, drift: (Math.random()-.5)*1.5
  }));
  let start = null;
  const dur = 3000;
  (function draw(ts) {
    if (!start) start=ts;
    const p = Math.min((ts-start)/dur, 1);
    ctx.clearRect(0,0,W,H);
    let alive = false;
    for (const c of pieces) {
      c.y+=c.speed; c.x+=c.drift; c.angle+=c.spin;
      const opacity = Math.max(0, 1-p*p*1.4);
      if (c.y<H+30) alive=true;
      ctx.save();
      ctx.globalAlpha = opacity;
      ctx.translate(c.x+c.w/2, c.y+c.h/2);
      ctx.rotate(c.angle);
      ctx.fillStyle = c.color;
      ctx.fillRect(-c.w/2,-c.h/2,c.w,c.h);
      ctx.restore();
    }
    if (alive&&p<1) requestAnimationFrame(draw);
    else canvas.remove();
  })(0);
}
