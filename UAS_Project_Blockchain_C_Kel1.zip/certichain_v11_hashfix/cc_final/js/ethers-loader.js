/**
 * ethers-loader.js — CertiChain
 * Memuat library ethers.js v6 (UMD) dengan fallback otomatis ke beberapa CDN.
 * Jika satu CDN diblokir/403/gagal, browser otomatis mencoba CDN berikutnya
 * secara berurutan sebelum menyerah.
 *
 * Cara pakai: letakkan <script src="js/ethers-loader.js"></script> SEBELUM
 * script lain yang memakai `ethers` (blockchain.js, dst). Script-script itu
 * sebaiknya dibungkus agar berjalan setelah event 'ethers:ready', atau cukup
 * pastikan urutan <script> tag standar tetap dipakai — loader ini berjalan
 * secara síncron (document.write-free) dengan teknik sequential <script> load.
 */
(function () {
  // Daftar CDN fallback, urut dari yang paling diutamakan.
  // Semua mengarah ke build UMD ethers v6 yang sama (window.ethers).
  var CDN_SOURCES = [
    'https://cdn.jsdelivr.net/npm/ethers@6.13.4/dist/ethers.umd.min.js',
    'https://unpkg.com/ethers@6.13.4/dist/ethers.umd.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/ethers/6.13.4/ethers.umd.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/ethers/6.7.0/ethers.umd.min.js'
  ];

  var idx = 0;

  function loadNext() {
    if (idx >= CDN_SOURCES.length) {
      console.error('[CertiChain] Semua sumber CDN ethers.js gagal dimuat. Periksa koneksi internet atau pengaturan jaringan (firewall/proxy mungkin memblokir CDN).');
      window.dispatchEvent(new CustomEvent('ethers:failed'));
      showEthersLoadError();
      return;
    }
    var url = CDN_SOURCES[idx];
    var script = document.createElement('script');
    script.src = url;
    script.async = false; // jaga urutan eksekusi

    script.onload = function () {
      if (typeof window.ethers !== 'undefined') {
        console.log('[CertiChain] ethers.js berhasil dimuat dari: ' + url);
        window.dispatchEvent(new CustomEvent('ethers:ready'));
      } else {
        // Script termuat tapi window.ethers tidak terdefinisi (jarang terjadi)
        idx++;
        loadNext();
      }
    };

    script.onerror = function () {
      console.warn('[CertiChain] Gagal memuat ethers.js dari: ' + url + ' — mencoba sumber berikutnya...');
      idx++;
      loadNext();
    };

    document.head.appendChild(script);
  }

  function showEthersLoadError() {
    // Tampilkan banner peringatan ke pengguna jika SEMUA CDN gagal
    document.addEventListener('DOMContentLoaded', function () {
      var banner = document.createElement('div');
      banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:#FEF2F2;border-bottom:2px solid #FECACA;color:#991B1B;padding:12px 20px;text-align:center;font-family:sans-serif;font-size:14px;font-weight:600;';
      banner.innerHTML = '⚠️ Gagal memuat library blockchain (ethers.js). Periksa koneksi internet Anda atau coba nonaktifkan VPN/firewall yang mungkin memblokir CDN, lalu muat ulang halaman.';
      document.body.prepend(banner);
    });
  }

  loadNext();
})();
