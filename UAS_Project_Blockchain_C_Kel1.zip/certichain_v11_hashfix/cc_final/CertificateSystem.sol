// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title CertificateSystem
 * @author Kelompok 1 - Blockchain C, Institut Teknologi PLN
 * @notice Smart contract untuk menerbitkan dan memverifikasi sertifikat pelatihan/kursus
 * @dev Deploy di Ethereum Sepolia Testnet menggunakan Remix IDE
 */
contract CertificateSystem {

    // ============================================================
    //  STRUCT: Blueprint data sertifikat yang disimpan on-chain
    // ============================================================
    struct Certificate {
        uint256 id;           // ID unik sertifikat
        string recipientName; // Nama peserta pelatihan
        string courseName;    // Nama kursus/pelatihan
        uint256 issueDate;    // Tanggal terbit (UNIX timestamp)
        bool isValid;         // Status: true = aktif, false = dicabut
        address issuedBy;     // Alamat wallet yang menerbitkan
        bytes32 certHash;     // Keccak256 hash dari data sertifikat
    }

    // ============================================================
    //  STATE VARIABLES
    // ============================================================

    // Pemilik kontrak (yang deploy = admin utama)
    address public owner;

    // Penghitung total sertifikat yang pernah dibuat
    uint256 public certificateCount;

    // Mapping: ID sertifikat → data Certificate
    mapping(uint256 => Certificate) private certificates;

    // Mapping: Siapa saja yang berhak menerbitkan sertifikat
    mapping(address => bool) public authorizedIssuers;

    // ============================================================
    //  TAMBAHAN: Mapping hash → ID sertifikat
    // ============================================================

    // Mapping: certHash → ID sertifikat (untuk pencarian by hash)
    mapping(bytes32 => uint256) private hashToId;

    // ============================================================
    //  TAMBAHAN (FIX): Nonce anti-tabrakan hash
    // ============================================================
    // hashNonce SELALU naik setiap kali sertifikat baru dibuat.
    // Dimulai dari 20 agar nilai hash awal berada "di atas 20"
    // sesuai permintaan, dan tidak akan pernah kembali/berulang
    // ke nilai yang sama karena sifatnya monotonically increasing.
    uint256 private hashNonce = 20;

    // ============================================================
    //  EVENTS: Dicatat di blockchain, bisa dilacak di Etherscan
    // ============================================================
    event CertificateCreated(
        uint256 indexed id,
        string recipientName,
        string courseName,
        address issuedBy,
        bytes32 certHash
    );

    event CertificateRevoked(
        uint256 indexed id,
        address revokedBy
    );

    event IssuerAuthorized(address indexed issuer);
    event IssuerRevoked(address indexed issuer);

    // ============================================================
    //  MODIFIERS: Reusable kondisi pengaman
    // ============================================================

    // Hanya owner yang bisa menjalankan fungsi ini
    modifier onlyOwner() {
        require(msg.sender == owner, "Hanya owner yang dapat melakukan ini");
        _;
    }

    // Hanya issuer yang sudah diotorisasi
    modifier onlyAuthorized() {
        require(
            authorizedIssuers[msg.sender] || msg.sender == owner,
            "Anda tidak memiliki izin menerbitkan sertifikat"
        );
        _;
    }

    // ============================================================
    //  CONSTRUCTOR: Dijalankan sekali saat kontrak di-deploy
    // ============================================================
    constructor() {
        owner = msg.sender;
        authorizedIssuers[msg.sender] = true; // Owner otomatis jadi issuer
        certificateCount = 0;
    }

    // ============================================================
    //  FUNGSI 1: createCertificate — Menerbitkan sertifikat baru
    // ============================================================
    /**
     * @notice Menerbitkan sertifikat baru ke blockchain
     * @param _recipientName Nama lengkap peserta
     * @param _courseName Nama kursus/pelatihan yang diikuti
     * @return newId ID sertifikat yang baru dibuat
     */
    function createCertificate(
        string memory _recipientName,
        string memory _courseName
    ) public onlyAuthorized returns (uint256 newId) {
        // Validasi: nama peserta tidak boleh kosong
        require(bytes(_recipientName).length > 0, "Nama peserta tidak boleh kosong");
        // Validasi: nama kursus tidak boleh kosong
        require(bytes(_courseName).length > 0, "Nama kursus tidak boleh kosong");

        // Increment ID, mulai dari 1
        certificateCount++;
        newId = certificateCount;

        // ── Hitung certHash dari data sertifikat ──
        // hashNonce dinaikkan DULU sebelum dipakai, supaya nilainya
        // selalu > 20 dan selalu berbeda dari nonce sertifikat manapun
        // sebelumnya (nonce tidak pernah turun / tidak pernah diulang).
        hashNonce++;

        bytes32 certHash = keccak256(abi.encodePacked(
            hashNonce,
            newId,
            _recipientName,
            _courseName,
            block.timestamp,
            msg.sender
        ));

        // ── Jaga-jaga ekstra: kalau (secara teori) certHash ini
        //    ternyata SUDAH pernah dipakai sertifikat lain, naikkan
        //    nonce lagi dan hitung ulang sampai benar-benar unik. ──
        while (hashToId[certHash] != 0) {
            hashNonce++;
            certHash = keccak256(abi.encodePacked(
                hashNonce,
                newId,
                _recipientName,
                _courseName,
                block.timestamp,
                msg.sender
            ));
        }

        // Simpan data sertifikat ke mapping
        certificates[newId] = Certificate({
            id: newId,
            recipientName: _recipientName,
            courseName: _courseName,
            issueDate: block.timestamp, // Waktu saat transaksi diproses
            isValid: true,              // Sertifikat aktif saat pertama dibuat
            issuedBy: msg.sender,       // Alamat yang mengirim transaksi
            certHash: certHash          // Hash unik sertifikat
        });

        // Simpan mapping hash → ID untuk pencarian by hash
        hashToId[certHash] = newId;

        // Emit event agar tercatat di log blockchain
        emit CertificateCreated(newId, _recipientName, _courseName, msg.sender, certHash);

        return newId;
    }

    // ============================================================
    //  FUNGSI 2: getCertificate — Mengambil data sertifikat by ID
    // ============================================================
    /**
     * @notice Mengambil seluruh data sertifikat berdasarkan ID
     * @param _id ID sertifikat yang ingin dilihat
     * @return Semua field dari struct Certificate termasuk certHash
     */
    function getCertificate(uint256 _id)
        public
        view
        returns (
            uint256 id,
            string memory recipientName,
            string memory courseName,
            uint256 issueDate,
            bool isValid,
            address issuedBy,
            bytes32 certHash
        )
    {
        // Validasi: ID harus valid (antara 1 dan total sertifikat)
        require(_id > 0 && _id <= certificateCount, "ID sertifikat tidak ditemukan");

        Certificate memory cert = certificates[_id];

        return (
            cert.id,
            cert.recipientName,
            cert.courseName,
            cert.issueDate,
            cert.isValid,
            cert.issuedBy,
            cert.certHash
        );
    }

    // ============================================================
    //  FUNGSI 2b: getCertificateByHash — Mengambil data by Hash
    // ============================================================
    /**
     * @notice Mengambil data sertifikat berdasarkan certHash
     * @param _certHash Hash sertifikat (bytes32)
     * @return Semua field dari struct Certificate
     */
    function getCertificateByHash(bytes32 _certHash)
        public
        view
        returns (
            uint256 id,
            string memory recipientName,
            string memory courseName,
            uint256 issueDate,
            bool isValid,
            address issuedBy,
            bytes32 certHash
        )
    {
        uint256 _id = hashToId[_certHash];
        require(_id > 0, "Hash sertifikat tidak ditemukan");

        Certificate memory cert = certificates[_id];

        return (
            cert.id,
            cert.recipientName,
            cert.courseName,
            cert.issueDate,
            cert.isValid,
            cert.issuedBy,
            cert.certHash
        );
    }

    // ============================================================
    //  FUNGSI 3: verifyCertificate — Memverifikasi keaslian by ID
    // ============================================================
    /**
     * @notice Memverifikasi apakah sertifikat asli dan masih aktif
     * @param _id ID sertifikat yang ingin diverifikasi
     * @return isAuthentic true jika sertifikat ada dan masih valid
     * @return message Pesan status hasil verifikasi
     */
    function verifyCertificate(uint256 _id)
        public
        view
        returns (bool isAuthentic, string memory message)
    {
        // Cek apakah ID ada dalam sistem
        if (_id == 0 || _id > certificateCount) {
            return (false, "TIDAK VALID: Sertifikat tidak ditemukan dalam sistem");
        }

        Certificate memory cert = certificates[_id];

        // Cek apakah sertifikat masih aktif (belum dicabut)
        if (!cert.isValid) {
            return (false, "TIDAK VALID: Sertifikat telah dicabut/direvoke");
        }

        return (true, "VALID: Sertifikat asli dan masih aktif");
    }

    // ============================================================
    //  FUNGSI 3b: verifyCertificateByHash — Verifikasi by Hash
    // ============================================================
    /**
     * @notice Memverifikasi sertifikat berdasarkan certHash
     * @param _certHash Hash sertifikat yang ingin diverifikasi
     * @return isAuthentic true jika sertifikat ada dan masih valid
     * @return message Pesan status hasil verifikasi
     */
    function verifyCertificateByHash(bytes32 _certHash)
        public
        view
        returns (bool isAuthentic, string memory message)
    {
        uint256 _id = hashToId[_certHash];

        if (_id == 0) {
            return (false, "TIDAK VALID: Hash sertifikat tidak ditemukan dalam sistem");
        }

        Certificate memory cert = certificates[_id];

        if (!cert.isValid) {
            return (false, "TIDAK VALID: Sertifikat telah dicabut/direvoke");
        }

        return (true, "VALID: Sertifikat asli dan masih aktif");
    }

    // ============================================================
    //  FUNGSI 4: revokeCertificate — Mencabut sertifikat by ID
    // ============================================================
    /**
     * @notice Mencabut (menonaktifkan) sertifikat yang sudah ada
     * @dev Hanya owner atau issuer yang berwenang
     * @param _id ID sertifikat yang ingin dicabut
     */
    function revokeCertificate(uint256 _id) public onlyAuthorized {
        // Validasi: ID harus valid
        require(_id > 0 && _id <= certificateCount, "ID sertifikat tidak ditemukan");

        // Validasi: sertifikat harus masih aktif untuk bisa dicabut
        require(certificates[_id].isValid, "Sertifikat sudah tidak aktif");

        // Ubah status isValid menjadi false (dicabut)
        certificates[_id].isValid = false;

        // Emit event pencabutan
        emit CertificateRevoked(_id, msg.sender);
    }

    // ============================================================
    //  FUNGSI 4b: revokeCertificateByHash — Cabut by Hash
    // ============================================================
    /**
     * @notice Mencabut sertifikat berdasarkan certHash
     * @param _certHash Hash sertifikat yang ingin dicabut
     */
    function revokeCertificateByHash(bytes32 _certHash) public onlyAuthorized {
        uint256 _id = hashToId[_certHash];
        require(_id > 0, "Hash sertifikat tidak ditemukan");
        require(certificates[_id].isValid, "Sertifikat sudah tidak aktif");

        certificates[_id].isValid = false;

        emit CertificateRevoked(_id, msg.sender);
    }

    // ============================================================
    //  FUNGSI (BONUS): getHashNonce — Cek nilai nonce hash saat ini
    // ============================================================
    /**
     * @notice Mengembalikan nilai hashNonce saat ini (untuk debugging)
     * @dev Nilai ini selalu > 20 dan selalu naik setiap penerbitan baru
     */
    function getHashNonce() public view returns (uint256) {
        return hashNonce;
    }

    // ============================================================
    //  FUNGSI 5 (BONUS): authorizeIssuer — Menambah penerbit
    // ============================================================
    /**
     * @notice Memberikan izin kepada alamat lain untuk menerbitkan sertifikat
     * @dev Hanya bisa dilakukan oleh owner
     * @param _issuer Alamat wallet yang ingin diberi izin
     */
    function authorizeIssuer(address _issuer) public onlyOwner {
        require(_issuer != address(0), "Alamat tidak valid");
        require(!authorizedIssuers[_issuer], "Alamat sudah diotorisasi");

        authorizedIssuers[_issuer] = true;
        emit IssuerAuthorized(_issuer);
    }

    /**
     * @notice Mencabut izin penerbit sertifikat
     * @param _issuer Alamat yang ingin dicabut izinnya
     */
    function revokeIssuer(address _issuer) public onlyOwner {
        require(_issuer != owner, "Tidak dapat mencabut izin owner");
        require(authorizedIssuers[_issuer], "Alamat bukan issuer aktif");

        authorizedIssuers[_issuer] = false;
        emit IssuerRevoked(_issuer);
    }
}
